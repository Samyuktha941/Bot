import requests
from textbase import bot, Message
from textbase.models import OpenAI
from typing import List

# Load your OpenAI API key
OpenAI.api_key = "my_api"
weather_api_key = "api"

# Prompt for GPT-3.5 Turbo
SYSTEM_PROMPT = """You are chatting with an AI. There are no specific prefixes for responses, so you can ask or talk about anything you like.
The AI will respond in a natural, conversational manner.Creating a captivating weather update for you, complete with an exciting bonus—a dynamic weather map! While we chat about anything under the sun, let's keep an eye on the actual sun too!
Feel free to start the conversation with any question or topic, and let's have a
pleasant chat!
"""

@bot()
def get_weather_info(city, api_key):
        """
        Get the weather information for a given city.
        """
        url = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}'.format(city, api_key)
        response = requests.get(url)
        if response.status_code == 200:
            weather_data = response.json()
            return weather_data
        else:
            raise Exception("Error getting weather information: {}".format(response.status_code))   
        
def on_message(message_history: List[Message], state: dict = None):
     # Get the weather information for the user's city
    if message_history[0].text.startswith("weather in "):
        city = message_history[0].text.split(" ")[1]
        weather_data = get_weather_info(city)

        # Generate GPT-3.5 Turbo response
        bot_response = OpenAI.generate(
            system_prompt=SYSTEM_PROMPT,
            message_history=message_history, # Assuming history is the list of user messages
            model="gpt-3.5-turbo",
            context={"weather_data": weather_data}
        )
    else:
    # Generate GPT-3.5 Turbo response
        bot_response = OpenAI.generate(
        system_prompt=SYSTEM_PROMPT,
        message_history=message_history, # Assuming history is the list of user messages
        model="gpt-3.5-turbo",
    )

    response = {
        "data": {
            "messages": [
                {
                    "data_type": "STRING",
                    "value": bot_response
                }
            ],
            "state": state
        },
        "errors": [
            {
                "message": ""
            }
        ]
    }

    return {
        "status_code": 200,
        "response": response
    }
    